http_path = "/"
css_dir = "/"
sass_dir = "sass"
images_dir = "../img"
javascripts_dir = "../js"
output_style = :compressed

CSSSlider
=========

A simple slider using CSS3 transitions, and jQuery

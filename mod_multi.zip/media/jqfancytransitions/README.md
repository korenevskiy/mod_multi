jqFancyTransitions
==================

Easy-to-use jQuery plugin for displaying your photos as slideshow with fancy transition effects.

For examples and documentation visit [http://workshop.rs/projects/jqfancytransitions/](http://workshop.rs/projects/jqfancytransitions/)

![http://workshop.rs/projects/jqfancytransitions/jqFancyTransitions2.png](http://workshop.rs/projects/jqfancytransitions/jqFancyTransitions2.png)

project was hosted on Google Code between Dec 2009 - March 2015
![http://workshop.rs/wp-content/uploads/2015/03/Screen-Shot-2015-03-13-at-3.14.15-PM.png](http://workshop.rs/wp-content/uploads/2015/03/Screen-Shot-2015-03-13-at-3.14.15-PM.png)
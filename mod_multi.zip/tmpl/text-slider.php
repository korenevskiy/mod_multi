<?php

// https://www.jqueryscript.net/plus/search.php?keyword=NathanBastiaans
//	modules/mod_multi/media/text-slider.js
// 

?>
<!--
        var settings = $.extend({
            timeout:     7500,
            nextItem:    0,
            currentItem: 1,
            count:       1,
			overlay:     0,
			debug:       0,
			classItem: ''
        }, options );
		-->

<script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="js/text-slider.js"></script>
<div class="slide">
	<div class="slider-item">
		Slide 1
	</div>
	<div class="slider-item">
		Slide 2
	</div>
	<div class="slider-item">
		Slide 3
	</div>
</div>
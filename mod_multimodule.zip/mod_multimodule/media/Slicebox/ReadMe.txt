Created by Codrops
License: http://tympanus.net/codrops/licensing/

Background Pattern(s) from http://subtlepatterns.com/
http://creativecommons.org/licenses/by-sa/3.0/deed.en_US

Demo images by ND Strupler:
http://www.flickr.com/photos/strupler/
Images licensed under a CC BY 2.0 License:
http://creativecommons.org/licenses/by/2.0/deed.en

